// ---------- kStarRepair Script ----------
// star repair and combine with starless script for PixInsight
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// --------------------------------------

#feature-id kStarRepair : kScripts Bundle > kStarRepair
#feature-info Star repair and combine script
#feature-icon kStarRepair.svg
#define TITLE "kStarRepair"
#define VERSION "1.0"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>

var SRParameters = {
  targetView: undefined,
  targetView2: undefined,
  satAmount: 1,
  replace: false,
  deblow: false,
  blendMode: 1,
  convolutionStrength: 2.0,
  deblowStrength: 1.5,
  saturationLevel: [
    [0.00000, 0.40000],
    [0.50000, 0.70000],
    [1.00000, 0.40000]
  ],

  updateSaturationLevel: function() {
    var satAmount = SRParameters.satAmount;
    SRParameters.saturationLevel = [
      [0.00000, satAmount * 0.40000],
      [0.50000, satAmount * 0.70000],
      [1.00000, satAmount * 0.40000]
    ];
  }
};

console.noteln("<br>Successfully loaded kStarRepair V", VERSION, "!<br>");

function krDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "kScripts - kStarRepair";

    // scaling
    this.scaledMinWidth = 700;
    this.scaledMinHeight = 380;

    // Title sizer
    this.titleSizer = new VerticalSizer;
    this.titleSizer.spacing = 4;

    this.titleBox = new Label(this);
    this.titleBox.text = "kStarRepair " + VERSION;
    this.titleBox.textAlignment = TextAlign_Center;
    this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #d7e7fa; border: 1px solid #ccc;";
    this.titleBox.setFixedHeight(30);

    this.instructionsBox = new Label(this);
    this.instructionsBox.text = "Script that repairs star color and mixes starless with stars.";
    this.instructionsBox.textAlignment = TextAlign_Center;
    this.instructionsBox.styleSheet = "font-size: 8pt; padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc;";
    this.instructionsBox.setFixedHeight(40);

    this.titleSizer.add(this.titleBox);
    this.titleSizer.addSpacing(5);
    this.titleSizer.add(this.instructionsBox);
    this.titleSizer.addSpacing(5);

    this.viewListLabel = new Label(this);
    this.viewListLabel.text = "Starless image";

    this.viewList2Label = new Label(this);
    this.viewList2Label.text = "Stars image";

    this.viewList = new ViewList(this);
    this.viewList.getMainViews();
    this.viewList.onViewSelected = function(view) {
        SRParameters.targetView = view;
    };

    this.viewList2 = new ViewList(this);
    this.viewList2.getMainViews();
    this.viewList2.onViewSelected = function(view2) {
        SRParameters.targetView2 = view2;
    };

    this.boostCtrl = new NumericControl(this);
    this.boostCtrl.label.text = "Color Boost";
    this.boostCtrl.setRange(0, 5);
    this.boostCtrl.setPrecision(1);
    this.boostCtrl.setValue(SRParameters.satAmount);
    this.boostCtrl.toolTip = "<p>Adjust the color saturation amount.</p>";
    this.boostCtrl.onValueUpdated = function(value) {
        SRParameters.satAmount = value;
        SRParameters.updateSaturationLevel();
    };

    this.replaceCheckbox = new CheckBox(this);
    this.replaceCheckbox.text = "Replace To Original";
    this.replaceCheckbox.checked = false;
    this.replaceCheckbox.toolTip = "<p>Check this box to replace the result with the original image.</p>";
    this.replaceCheckbox.onClick = function() {
        SRParameters.replace = this.checked;
        if(SRParameters.replace == true){
          console.noteln("[ON] Replace Stars To Original Image<br>");
        } else {
          console.criticalln("[OFF] Replace Stars To Original Image<br>");
        }
    };

    this.Label = new Label(this);
    this.Label.text = "Star DeBlowing:";
    this.Label.textAlignment = TextAlign_Center;
    this.Label.styleSheet = "font-weight: bold; font-size: 11pt;";
    this.Label.enabled = false;

    let debSizer = new VerticalSizer();
    debSizer.spacing = 10;

    this.convolutionCtrl = new NumericControl(this);
    this.convolutionCtrl.label.text = "Convolution Strength";
    this.convolutionCtrl.setRange(0, 10);
    this.convolutionCtrl.setPrecision(1);
    this.convolutionCtrl.setValue(SRParameters.convolutionStrength);
    this.convolutionCtrl.toolTip = "<p>Adjust the strength of the initial convolution which is added on mask. More = softer mask and less stars are used to deblow</p>";
    this.convolutionCtrl.onValueUpdated = function(value) {
        SRParameters.convolutionStrength = value;
    };
    this.convolutionCtrl.enabled = false;

    this.deblowCtrl = new NumericControl(this);
    this.deblowCtrl.label.text = "Deblow Strength";
    this.deblowCtrl.setRange(0, 10);
    this.deblowCtrl.setPrecision(1);
    this.deblowCtrl.setValue(SRParameters.deblowStrength);
    this.deblowCtrl.toolTip = "<p>Adjust the strength of the deblow convolution.</p>";
    this.deblowCtrl.onValueUpdated = function(value) {
        SRParameters.deblowStrength = value;
    };
    this.deblowCtrl.enabled = false;

    debSizer.add(this.convolutionCtrl);
    debSizer.add(this.deblowCtrl);
    debSizer.addSpacing(10);

    this.deblowCheckbox = new CheckBox(this);
    this.deblowCheckbox.text = "Star DeBlowing";
    this.deblowCheckbox.checked = false;
    this.deblowCheckbox.toolTip = "<p>Enable star deblowing to adjust core brightness.</p>";
    this.deblowCheckbox.onClick = function() {
            SRParameters.deblow = this.checked;
            var dlg = this.dialog;

            if(SRParameters.deblow == true) {
                dlg.Label.enabled = true;
                dlg.convolutionCtrl.enabled = true;
                dlg.deblowCtrl.enabled = true;
                console.noteln("[ON] Star DeBlowing<br>");
            } else {
                dlg.Label.enabled = false;
                dlg.convolutionCtrl.enabled = false;
                dlg.deblowCtrl.enabled = false;
                console.criticalln("[OFF] Star DeBlowing<br>");
            }
            dlg.adjustToContents();
        };

    this.screenCheckbox = new CheckBox(this);
    this.screenCheckbox.text = "Screen Blend";
    this.screenCheckbox.checked = true;
    this.screenCheckbox.toolTip = "<p>Enable screen blending method. Disabled means blending via addition.</p>";
    this.screenCheckbox.onClick = function(){
      SRParameters.blendMode = this.checked;
      if(SRParameters.blendMode == true){
        console.noteln("[ON] Screen Blending<br>");
      } else {
        console.criticalln("[OFF] Screen Blending<br>");
      }
    }

    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "Written by Igor Koprowicz\n© Copyright 2024-2025";
    this.authorshipLabel.textAlignment = TextAlign_Center;

    let buttonSizer = new HorizontalSizer;
    buttonSizer.spacing = 4;

    this.executeButton = new ToolButton(this);
    this.executeButton.icon = this.scaledResource(":/floating-window/commit.png");
    this.executeButton.setScaledFixedSize(20, 20);
    this.executeButton.toolTip = "Execute script";
    this.executeButton.onClick = () => {
        this.ok();
    };

    this.infoButton = new ToolButton(this);
    this.infoButton.icon = this.scaledResource(":/icons/info.png");
    this.infoButton.setScaledFixedSize(20, 20);
    this.infoButton.toolTip = "Script information";
    this.infoButton.onClick = () => {
        new MessageBox(
          "kStarRepair " + VERSION + "\nRelease date: 4 February 2025\n\n" +
          "This script is handling repairing stars in astrophotography images.\n\n" +
          "Key Features:\n" +
          "• Color boost - adding saturation and vibrance to your stars image.\n" +
          "• Core repair - here scripts gets rid of blown out star cores using mask and convolution.\n\n" +
          "Usage:\n" +
          "1. Select a linear state extracted stars image\n" +
          "2. Adjust color boost slider,\n" +
          "3. Select if you want to replace your image to original(starless)\n" +
          "4. Select if you want to enable star deblowing function.\n\n" +
          "Star deblowing method by Jędrzej Adaszek\n" +
          "Created, developed and method by Igor Koprowicz\n" +
          "© Copyright 2025",
          TITLE,
          StdIcon_Information,
          StdButton_Ok
        ).execute();
    };

    this.closeButton = new ToolButton(this);
    this.closeButton.icon = this.scaledResource(":/floating-window/close.png");
    this.closeButton.setScaledFixedSize(20, 20);
    this.closeButton.toolTip = "Close script";
    this.closeButton.onClick = () => {
        this.cancel();
    };

    this.setLabel = new Label(this);
    this.setLabel.text = "Settings:";
    this.setLabel.textAlignment = TextAlign_Left;
    this.setLabel.styleSheet = "font-weight: bold; font-size: 8pt;";
    this.setLabel.enabled = false;

    buttonSizer.add(this.executeButton);
    buttonSizer.add(this.closeButton);
    buttonSizer.addStretch();
    buttonSizer.add(this.authorshipLabel);
    buttonSizer.addStretch();
    buttonSizer.add(this.infoButton);

    let checkboxSizer = new HorizontalSizer();
    checkboxSizer.add(this.replaceCheckbox);
    checkboxSizer.addSpacing(10);
    checkboxSizer.add(this.deblowCheckbox);
    checkboxSizer.addSpacing(10);
    checkboxSizer.add(this.screenCheckbox);
    checkboxSizer.addStretch();

    this.verSizer = new VerticalSizer();
    this.verSizer.addStretch();
    this.verSizer.margin = 20;
    this.verSizer.add(this.titleSizer);
    this.verSizer.addSpacing(5);
    this.verSizer.add(this.viewListLabel);
    this.verSizer.addSpacing(5);
    this.verSizer.add(this.viewList);
    this.verSizer.addSpacing(10);
    this.verSizer.add(this.viewList2Label);
    this.verSizer.addSpacing(5);
    this.verSizer.add(this.viewList2);
    this.verSizer.addSpacing(10);
    this.verSizer.add(this.boostCtrl);
    this.verSizer.addSpacing(15);
    this.verSizer.add(this.setLabel);
    this.verSizer.addSpacing(5);
    this.verSizer.add(checkboxSizer);
    this.verSizer.addSpacing(40);
    this.verSizer.add(buttonSizer);
    this.verSizer.addStretch();

    this.verSizer2 = new VerticalSizer();
    this.verSizer2.addSpacing(5);
    this.verSizer2.add(this.Label);
    this.verSizer2.addSpacing(10);
    this.verSizer2.add(debSizer);
    this.verSizer2.addStretch();
    this.verSizer2.margin = 20;

    this.sizer = new HorizontalSizer();
    this.sizer.add(this.verSizer);
    this.sizer.spacing = 0;
    this.sizer.add(this.verSizer2);

}

krDialog.prototype = new Dialog;

function applyStarProcessing(view2) {
    var P = new PixelMath;
    P.expression = view2.id;
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.createNewImage = true;
    P.showNewImage = false;
    P.newImageId = "StarLuminance";
    P.newImageColorSpace = PixelMath.prototype.Gray;
    P.executeOn(view2);

    var luminanceView = View.viewById("StarLuminance");

    var C = new Convolution;
    C.mode = Convolution.prototype.Parametric;
    C.sigma = SRParameters.convolutionStrength;
    C.shape = 2.00;
    C.aspectRatio = 1.00;
    C.rotation = 0.00;
    C.executeOn(luminanceView);

    view2.mask = luminanceView;
    view2.maskEnabled = true;
    view2.maskInverted = false;

    var C2 = new Convolution;
    C2.mode = Convolution.prototype.Parametric;
    C2.sigma = SRParameters.deblowStrength;
    C2.shape = 2.00;
    C2.aspectRatio = 1.00;
    C2.rotation = 0.00;
    C2.executeOn(view2);

    view2.maskEnabled = false;
    view2.mask = null;

    luminanceView.window.forceClose();
}

function applyColorSaturation(view2) {
   var PCS = new ColorSaturation;
   PCS.HS = SRParameters.saturationLevel;
   PCS.HSt = ColorSaturation.prototype.AkimaSubsplines;
   PCS.hueShift = 0.000;
   PCS.executeOn(view2);
}

function applyStarRepair(view2) {
  var PSCNR = new SCNR;
  PSCNR.amount = 1.00;
  PSCNR.protectionMethod = SCNR.prototype.AverageNeutral;
  PSCNR.colorToRemove = SCNR.prototype.Green;
  PSCNR.preserveLightness = true;
  PSCNR.executeOn(view2);

  var invert1 = new Invert;
  invert1.executeOn(view2);

  var PSCNR2 = new SCNR;
  PSCNR2.amount = 1.00;
  PSCNR2.protectionMethod = SCNR.prototype.AverageNeutral;
  PSCNR2.colorToRemove = SCNR.prototype.Green;
  PSCNR2.preserveLightness = true;
  PSCNR2.executeOn(view2);

  var invert2 = new Invert;
  invert2.executeOn(view2);
}

function combineViews(view, view2) {
    var P001 = new PixelMath;
    if (SRParameters.blendMode == true) {
        P001.expression = "combine(" + view2.id + "," + view.id + ",op_screen())";
    } else if (SRParameters.blendMode == false) {
        P001.expression = view.id + " + " + view2.id;
    }
    P001.expression1 = "";
    P001.expression2 = "";
    P001.expression3 = "";
    P001.useSingleExpression = true;
    P001.symbols = "";
    P001.clearImageCacheAndExit = false;
    P001.cacheGeneratedImages = false;
    P001.generateOutput = true;
    P001.singleThreaded = false;
    P001.optimization = true;
    P001.use64BitWorkingImage = false;
    P001.rescale = false;
    P001.rescaleLower = 0;
    P001.rescaleUpper = 1;
    P001.truncate = true;
    P001.truncateLower = 0;
    P001.truncateUpper = 1;
    if(SRParameters.replace == false){
      P001.createNewImage = true;
      P001.showNewImage = true;
      P001.newImageId = "Combined";
    } else{
      P001.createNewImage = false;
    }
    P001.newImageWidth = 0;
    P001.newImageHeight = 0;
    P001.newImageAlpha = false;
    P001.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P001.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
    P001.executeOn(view);
}

function showDialog() {
    var dialog = new krDialog();
    return dialog.execute();
}

function main() {
    let retVal = showDialog();

    if(retVal){
      if (SRParameters.targetView == undefined && SRParameters.targetView2 == undefined) {
        console.criticalln("!!! You haven't chosen any view !!!")
      } else if (SRParameters.targetView == undefined || SRParameters.targetView2 == undefined) {
        console.criticalln("!!! You need to choose second view !!!")
      } else {
          if(SRParameters.targetView.image.colorSpace !== 0 && SRParameters.targetView2.image.colorSpace !== 0){
            console.writeln("Processing RGB images...")
            if(SRParameters.deblow == 1){
              applyStarProcessing(SRParameters.targetView2);
            }
            applyColorSaturation(SRParameters.targetView2);
            applyStarRepair(SRParameters.targetView2);
            combineViews(SRParameters.targetView, SRParameters.targetView2);
            console.noteln("Successfully repaired stars!")
          } else if(SRParameters.targetView.image.colorSpace !== 1 && SRParameters.targetView2.image.colorSpace !== 1){
            console.writeln("Processing monochrome images...");
            if(SRParameters.deblow == 1){
              applyStarProcessing(SRParameters.targetView2);
            }
            combineViews(SRParameters.targetView, SRParameters.targetView2);
            console.noteln("Successfully repaired stars!")
          } else {
            console.criticalln("Cannot process: Image is in undefined colorspace.")
          }
        }
    } else {
      console.criticalln("Canceled repairing.")
    }
}

main();
